from apps.bookings.models import Booking

def is_conflict(resource, start_time, end_time):
    conflicts = Booking.objects.filter(
        resource=resource,
        start_time__lt=end_time,
        end_time__gt=start_time,
        status='approved'
    )
    return conflicts.exists()