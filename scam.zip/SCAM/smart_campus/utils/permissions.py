def is_admin(user):
    return user.role == 'admin'

def is_faculty(user):
    return user.role == 'faculty'

def is_student(user):
    return user.role == 'student'