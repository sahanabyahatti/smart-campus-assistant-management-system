"""
URL configuration for smart_campus project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path, include

urlpatterns = [
    path('admin/', admin.site.urls),

    # Users
    path('api/users/', include('apps.users.urls')),

    # Resources
    path('api/resources/', include('apps.resources.urls')),

    # Bookings
    path('api/bookings/', include('apps.bookings.urls')),

    # Analytics
    path('api/analytics/', include('apps.analytics.urls')),

    # Notifications (optional)
    path('api/notifications/', include('apps.notifications.urls')),
]