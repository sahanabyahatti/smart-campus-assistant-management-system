const BASE_URL = "http://127.0.0.1:8000/api";

// Show message
function showMessage(msg, isError = false) {
    const el = document.getElementById("message");
    el.innerText = msg;
    el.style.color = isError ? "red" : "lightgreen";
}

// Convert datetime-local to Django format
function formatDate(date) {
    return date + ":00";
}

// ---------------- RESOURCE ----------------

async function createResource() {
    const data = {
        name: document.getElementById("res_name").value,
        type: document.getElementById("res_type").value,
        capacity: document.getElementById("res_capacity").value,
        location: document.getElementById("res_location").value
    };

    const res = await fetch(`${BASE_URL}/resources/create/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    const result = await res.json();
    showMessage(result.message || result.error);
}

async function getResources() {
    const res = await fetch(`${BASE_URL}/resources/`);
    const data = await res.json();

    const list = document.getElementById("resourcesList");
    list.innerHTML = "";

    data.forEach(r => {
        const li = document.createElement("li");
        li.innerText = `${r.id} - ${r.name} (${r.type})`;
        list.appendChild(li);
    });
}

// ---------------- BOOKING ----------------

async function createBooking() {
    const data = {
        resource_id: document.getElementById("resource_id").value,
        start_time: formatDate(document.getElementById("start_time").value),
        end_time: formatDate(document.getElementById("end_time").value),
        purpose: document.getElementById("purpose").value
    };

    const res = await fetch(`${BASE_URL}/bookings/create/`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    });

    const result = await res.json();

    if (res.status === 400) {
        showMessage(result.error, true);
    } else {
        showMessage(result.message);
    }
}

async function getBookings() {
    const res = await fetch(`${BASE_URL}/bookings/`);
    const data = await res.json();

    const list = document.getElementById("bookingsList");
    list.innerHTML = "";

    data.forEach(b => {
        const li = document.createElement("li");
        li.innerText = `Resource ${b.resource_id} | ${b.start_time} - ${b.end_time}`;
        list.appendChild(li);
    });
}