from django.urls import path
from .views import get_usage

urlpatterns = [
    path('', get_usage),
]