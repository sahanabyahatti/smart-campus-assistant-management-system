from rest_framework.decorators import api_view
from rest_framework.response import Response
from apps.bookings.models import Booking

@api_view(['GET'])
def get_usage(request):
    total_bookings = Booking.objects.count()
    return Response({
        "total_bookings": total_bookings
    })