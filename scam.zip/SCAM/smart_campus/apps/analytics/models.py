from django.db import models
from apps.resources.models import Resource

class ResourceUsage(models.Model):
    resource = models.ForeignKey(Resource, on_delete=models.CASCADE)
    date = models.DateField()
    usage_hours = models.FloatField()