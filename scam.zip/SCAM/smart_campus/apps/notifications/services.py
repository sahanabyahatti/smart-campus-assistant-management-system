def send_booking_notification(user, message):
    print(f"Notification to {user}: {message}")