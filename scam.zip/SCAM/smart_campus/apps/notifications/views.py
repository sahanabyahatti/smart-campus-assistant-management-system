from rest_framework.decorators import api_view
from rest_framework.response import Response

@api_view(['GET'])
def test_notification(request):
    return Response({"message": "Notification system working"})