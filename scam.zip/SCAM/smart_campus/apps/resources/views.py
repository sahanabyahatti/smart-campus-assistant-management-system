from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import Resource

@api_view(['POST'])
def create_resource(request):
    resource = Resource.objects.create(
        name=request.data.get('name'),
        type=request.data.get('type'),
        capacity=request.data.get('capacity'),
        location=request.data.get('location')
    )
    return Response({"message": "Resource created"})


@api_view(['GET'])
def get_resources(request):
    resources = Resource.objects.all().values()
    return Response(resources)