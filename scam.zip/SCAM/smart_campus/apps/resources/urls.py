from django.urls import path
from .views import create_resource, get_resources

urlpatterns = [
    path('create/', create_resource),
    path('', get_resources),
]