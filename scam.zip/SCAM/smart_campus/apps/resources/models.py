from django.db import models

class Resource(models.Model):
    RESOURCE_TYPES = (
        ('classroom', 'Classroom'),
        ('lab', 'Lab'),
        ('hall', 'Seminar Hall'),
        ('sports', 'Sports Facility'),
    )

    name = models.CharField(max_length=100)
    type = models.CharField(max_length=50, choices=RESOURCE_TYPES)
    capacity = models.IntegerField()
    location = models.CharField(max_length=255)
    is_active = models.BooleanField(default=True)

    def __str__(self):
        return self.name