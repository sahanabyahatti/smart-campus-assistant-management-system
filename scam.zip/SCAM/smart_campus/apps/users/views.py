from rest_framework.decorators import api_view
from rest_framework.response import Response
from .models import User

@api_view(['POST'])
def create_user(request):
    user = User.objects.create(
        username=request.data.get('username'),
        role=request.data.get('role'),
        password="1234"
    )
    return Response({"message": "User created"})