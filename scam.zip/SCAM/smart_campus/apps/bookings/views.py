from rest_framework.decorators import api_view
from rest_framework.response import Response
from apps.bookings.models import Booking
from apps.resources.models import Resource
from apps.users.models import User
from utils.helpers import is_conflict


@api_view(['POST'])
def create_booking(request):
    user = User.objects.first()  # temporary

    resource_id = request.data.get('resource_id')
    start_time = request.data.get('start_time')
    end_time = request.data.get('end_time')
    purpose = request.data.get('purpose')

    resource = Resource.objects.get(id=resource_id)

    if is_conflict(resource, start_time, end_time):
        return Response({"error": "Resource already booked!"}, status=400)

    booking = Booking.objects.create(
        user=user,
        resource=resource,
        start_time=start_time,
        end_time=end_time,
        purpose=purpose,
        status='approved'
    )

    return Response({"message": "Booking successful!"})


@api_view(['GET'])
def get_bookings(request):
    bookings = Booking.objects.all().values()
    return Response(bookings)